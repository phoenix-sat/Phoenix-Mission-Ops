# Spice test file for ASU Ground Station.
# Developer:
#   Jeremy Jakubowski

import numpy as np
import spiceypy as spice
import plotly
from plotly.graph_objs import *

# Print out the toolkit version
spice.furnsh("./GSISS.setup")

EarthRadius = 6371 #km
step = 1000
# we are going to get positions between these two dates
utc = ['Jun 11, 2017', 'Jun 13, 2017']

# get et values one and two, we could vectorize str2et
etOne = spice.str2et(utc[0])
etTwo = spice.str2et(utc[1])

#print("ET One: {}, ET Two: {}".format(etOne, etTwo))

# get times
times = [x*(etTwo-etOne)/step + etOne for x in range(step)]

#check first few times:
#print(times[0:3])

#help(spice.spkezp)

#Run spkpos as a vectorized function
positionsSAT, lightTimesSAT = spice.spkpos('-125544', times, 'J2000', 'NONE', '399')
positionsGS, lightTimesGS = spice.spkpos('-999999', times, 'J2000', 'NONE', '399')

LATLONGS = np.zeros(shape=(181,361,3))
for LONG in range(181):
	for LAT in range(361):
		LATLONGS.itemset((LONG,LAT,0),EarthRadius*np.cos(LAT*(np.pi/180))*np.cos(LONG*(np.pi/180)))
		LATLONGS.itemset((LONG,LAT,1),EarthRadius*np.cos(LAT*(np.pi/180))*np.sin(LONG*(np.pi/180)))
		LATLONGS.itemset((LONG,LAT,2),EarthRadius*np.sin(LAT*(np.pi/180)))

LINES = []
for LONG in range(181):
	trace = {
    		'x': LATLONGS[LONG,:, 0], # X coordinates
    		'y': LATLONGS[LONG,:, 1], # Y coordinates
    		'z': LATLONGS[LONG,:, 2], # Z coordinates
    		'name': 'Longitude Lines',
    		'mode': 'lines',
		'legendgroup': "longs",
		'showlegend': False,
		'type': "scatter3d",
    		'line': {
			'color': 'rgb(142, 124, 195)'
		}
	}
	LINES.append(trace)

for LAT in range(361):
        trace = {
                'x': LATLONGS[:,LAT, 0], # X coordinates
                'y': LATLONGS[:,LAT, 1], # Y coordinates
                'z': LATLONGS[:,LAT, 2], # Z coordinates
                'name': 'Latitude Lines',
                'mode': 'lines',
                'legendgroup': "lats",
                'showlegend': False,
                'type': "scatter3d",
                'line': {
                        'color': 'rgb(142, 124, 195)'
                }
        }
        LINES.append(trace)

SATtrace = LINES.append({
	'x': positionsSAT[:, 0], # X coordinates
	'y': positionsSAT[:, 1], # Y coordinates
	'z': positionsSAT[:, 2], # Z coordinates
	'name': 'ISS',
	'mode': 'lines',
	'type': 'scatter3d',
	'line': {
		'width': '3'
	}
})

GStrace = LINES.append({
	'x': positionsGS[:, 0], # X coordinates
	'y': positionsGS[:, 1], # Y coordinates
	'z': positionsGS[:, 2], # Z coordinates
	'name': 'ASU Ground Station',
	'mode':'lines',
	'type': 'scatter3d',
	'line': {
		'width': '3'
	}
})

layout = Layout(title="ISS & ASU-GS Position Example")

fig = dict(data=LINES, layout=layout)
plotly.offline.plot(fig)
