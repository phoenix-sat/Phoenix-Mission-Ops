/* 

    Program developed for the ASU Satellite tracking ground station for determining
    when a satellite is above a certain elevation angle above the horizon at a given point
    on Earth.
    
    Developed by:
        Jeremy Jakubowski

*/

#include <stdio.h>
#include <string.h>
#include "SpiceUsr.h"
 
int main()
{
 
      /*
      Local constants
      */
      #define META    "GSISS.setup"
      #define MAXWIN  200000
      #define MAXIVL  ( MAXWIN / 2 )
      #define TIMFMT  "YYYY MON DD HR:MN:SC.###### TDB::RND::TDB"
      #define TIMLEN  36
 
      /*
      Local variables
      */
      SPICEDOUBLE_CELL      ( cnfine, MAXWIN );
      SPICEDOUBLE_CELL      ( result, MAXWIN );
 
      SpiceChar             * abcorr;
      SpiceChar               begstr [ TIMLEN ];
      SpiceChar             * back;
      SpiceChar             * bframe;
      SpiceChar             * bshape;
      SpiceChar             * crdsys;
      SpiceChar             * coord;
      SpiceChar               endstr [ TIMLEN ];
      SpiceChar             * frame;
      SpiceChar             * fframe;
      SpiceChar             * front;
      SpiceChar             * fshape;
      SpiceChar             * obsrvr;
      SpiceChar             * relate;
      SpiceChar             * target;
 
      SpiceDouble             adjust;
      SpiceDouble             et0;
      SpiceDouble             et1;
      SpiceDouble             finish;
      SpiceDouble             refval;
      SpiceDouble             start;
      SpiceDouble             step;
 
      SpiceInt                i;

      furnsh_c ( META );

/* Search window... */
      str2et_c ( "Jun 11, 2017",  &et0 );
      str2et_c ( "Jun 13, 2017",  &et1 );
 
      wninsd_c ( et0, et1, &cnfine );

      obsrvr = "-999999";
      target = "-125544";
      frame  = "IAU_EARTH";

      /*
      The coordinate system is latitudinal; in this system,
      in the IAU_EARTH frame, the coordinate "latitude"
      is equivalent to elevation.
      */
      crdsys = "LATITUDINAL";
      coord  = "LATITUDE";

      /*
      The relational operator for this search is "greater
      than" and the reference value is 10 degrees (converted
      to radians).
      */
      relate = ">";
      refval = 10.0 * rpd_c();
 
      abcorr = "NONE";
 
      /*
      Set the step size for this search. The step must
      be shorter than the shortest interval over which
      the elevation is increasing or decreasing.
      We pick a conservative value: 30 seconds. Units
      expected by SPICE are TDB seconds.
      */
      step   =  30;
 
      /*
      The adjustment value isn't used for this search;
      set it to 0.
      */
      adjust = 0.0;
 
      /*
      The number of intervals to be accommodated
      in the workspace windows to be dynamically allocated
      by gfposc_c is specified by the parameter MAXIVL.
 
      Execute the search.
      */
      printf ( "\n\nStarting elevation search.\n" );
 
      gfposc_c ( target, frame, abcorr, obsrvr,
                 crdsys, coord, relate, refval,
                 adjust, step,  MAXIVL, &cnfine, &result );
 
      printf ( "Done.\n" );
 
      /*
      Display the times of rise and set.
      */
      printf ( "\nTimes of ISS rise/set as seen from ASU GS:\n\n" );
 
      for ( i = 0;  i < wncard_c( &result );  i++ )
      {
         /*
         Fetch the start and stop times of the Ith
         interval from the window `result'.
         */
         wnfetd_c ( &result, i, &start, &finish );
 
         timout_c ( start,  TIMFMT, TIMLEN, begstr );
         timout_c ( finish, TIMFMT, TIMLEN, endstr );
 
         printf ( "   %s   %s\n", begstr, endstr );
      }
 
      printf ( "\n" );
 
      return ( 0 );
   }
